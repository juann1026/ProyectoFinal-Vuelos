/* globals Chart:false, feather:false */

var numero4=0;

function getnumero2(){
  getnumero();

  return numero4;
}
function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
   if ((new Date().getTime() - start) > milliseconds) {
    break;
   }
  }
 }

async function getnumero(){
      
     

        const response = await fetch("HTTP://localhost:8081/vuelos/origen");
        const vuelos = await response.json();
        let tableBody=``;
        var i=0;
        var numero=0;

        
        vuelos.forEach((vuelo, index) => {
          i+=1;
            //console.log(vuelos[i].asientos);     
            numero+=vuelo.asientos;
            //console.log(numero)
        });

        numero4=numero;
        console.log(numero4)
       
        
             
}
window.addEventListener('load', function() {
    generarTabla();
    
    //console.log(numero4)

});

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}




async function generarTabla(){
  await getnumero();
(() => {
  'use strict'

  feather.replace({ 'aria-hidden': 'true' })

  // Graphs
  const ctx = document.getElementById('myChart')
  // eslint-disable-next-line no-unused-vars
  const myChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [
        'Lunes',
        'Martes',
        'Miercoles',
        'Jueves',
        'Viernes',
        'Sabado',
        'Domingo'
      ],
      datasets: [{
        data: [
          numero4,
          numero4+30,
          numero4-80,
          numero4+100,
          numero4-200,
          numero4-50,
          numero4+600
        ],
        lineTension: 0,
        backgroundColor: 'transparent',
        borderColor: '#007bff',
        borderWidth: 4,
        pointBackgroundColor: '#007bff'
      }]
    },
    options: {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: false
          }
        }]
      },
      legend: {
        display: false
      }
    }
  })
})()}
