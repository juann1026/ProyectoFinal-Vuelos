//import sha256 from 'crypto-js/sha256';
//import hmacSHA512 from 'crypto-js/hmac-sha512'; 
////require.config({
//    packages: [
//        {
//            name: 'crypto-js',
//            location: 'path-to/bower_components/crypto-js',
//            main: 'index'
//        }
//    ]
//});
// 
//require(["crypto-js/aes", "crypto-js/sha256"], function (AES, SHA256) {
//    console.log(SHA256("Message"));
//});


//const Iniciar = async(username,password) => {
//
//
//     let data = new URLSearchParams({
//         "username": `${username}`,
//         "password": `${password}`
//     });
// 
//     const response = await fetch ("HTTP://localhost:8081/vuelos/login" ,{
//     method:"POST",
//     mode:"no-cors",
//     headers:{"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"},
//     body : data
//     })
//     .then(response => console.log(response.status))
//     //.then(response => response.json())
//     //.then(json => console.log(json))
//
//     if(response.status == 0){
//        console.log("holaaaa")
//        document.getElementById('vuelo_personalizado').style.display='block';
//        document.getElementById('SIGIN').style.display='none';
//
//    }
//     
// 
// };

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
  }

document.getElementById("button-addon2")
.addEventListener("click",(evt) =>{
    evt.preventDefault();
    const origen = document.getElementById("Origen").value;
    const destino = document.getElementById("Destino").value;
    const fechainicio = document.getElementById("FechaInicio").value;
    const fechafin = document.getElementById("FechaFin").value;
    const companyia = document.getElementById("Compañia").value;
    const precio = document.getElementById("Precio").value;
    const asientos = getRandomInt(0,1000);


    if(origen!="" && destino!="" && fechainicio!="" && fechafin!="" &&companyia!="",precio!=""){
         pedirVuelo(origen,destino,fechainicio,fechafin,companyia,precio,asientos);
         document.getElementById("tablavuelos").innerHTML = `<h2>Vuelo Insertado</h2>
         <h3>Su vuelo con: </h3> 
         <h3>Origen ${origen}</h3>
         <h3>Destino ${destino}</h3>
         <h3>Fecha de Inicio ${fechainicio}</h3>
         <h3>Fecha de Fin ${fechafin}</h3>
         <h3>Precio estimado ${precio}€</h3>
         <h3>Compañia ${companyia}</h3>
         <h3>Ha sido insertado con un total de  ${asientos} asientos</h3>
         `;
    }
    else{
        document.getElementById("tablavuelos").innerHTML = `<h2>Complete todos los campos</h2>`;
    }

    


    
});


const Iniciar = async(username,password) => {

    const response = await fetch("HTTP://localhost:8081/vuelos/users");
    const users = await response.json();
    let tableBody=``;
    
    users.forEach((user, index) => {
        console.log(user)     
        if(user.username==username && user.password==password){
            console.log("holaaaa")
            document.getElementById('vuelo_personalizado').style.display='block';
            document.getElementById('SIGIN').style.display='none';
            document.getElementById('botoniniciar').classList
        }
    });
}
 document.getElementById("botoniniciar")
 .addEventListener("click",(evt) =>{
     evt.preventDefault();
     
    // require.config({
    //    paths: {
    //        'crypto-js': '../node_modules/crypto-js/crypto-js'
    //    }
    //});
    //
    //require(["crypto-js"], function (CryptoJS) {
    //    console.log(CryptoJS.HmacSHA1("Message", "SHA-256"));
    //});
    

     const username = document.getElementById("username").value;
     const password = document.getElementById("password").value;

     let message = password;
     let key = 'secret';
    //const HmacSHA256 = require('crypto-js/hmac-sha256');
    //const CryptoJS = require('crypto-js');

     console.log('hmac-sha256: ' + CryptoJS.HmacSHA512(message, key));
     console.log('sha512: ' + CryptoJS.SHA512(message));

     console.log('hmac-sha256: ' + CryptoJS.HmacSHA256(message, key));
        message = CryptoJS.HmacSHA256(message, key);
        
     if(username!="" && password!="" ){
         Iniciar(username,message);
     }
     
    
 });
 



const listVuelosOrigen = async () => {

    document.getElementById('display').style.display='block';
    const origen = document.getElementById("Origen").value;
    const destino = document.getElementById("Destino").value;
    const fechainicio = document.getElementById("FechaInicio").value;
    const fechafin = document.getElementById("FechaFin").value;



    if(origen=="" && destino=="" && fechainicio=="" && fechafin==""){

        const response = await fetch("HTTP://localhost:8081/vuelos/origen");
        const vuelos = await response.json();
        let tableBody=``;
        
        vuelos.forEach((vuelo, index) => {
            console.log(vuelo)     
            tableBody += `<tr>
            <td class='centered'>${vuelo.origen}</td>
            <td class='centered'>${vuelo.destino}</td>
            <td class='centered'>${vuelo.fechainicio}</td>
            <td class='centered'>${vuelo.fechafin}</td>
            <td class='centered'>${vuelo.companyia}</td>
            <td class='centered'>${vuelo.precio}</td>
            <td class='centered'>${vuelo.asientos}</td>
            </tr>`
        });
            document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
    }
    if(origen=="" && destino=="" && fechainicio!="" && fechafin==""){
    
        const response = await fetch("HTTP://localhost:8081/vuelos/fechainicio?fechainicio="+fechainicio);
        const vuelos = await response.json();
        let tableBody=``;
        
        vuelos.forEach((vuelo, index) => {
            console.log(vuelo)     
            tableBody += `<tr>
            <td class='centered'>${vuelo.origen}</td>
            <td class='centered'>${vuelo.destino}</td>
            <td class='centered'>${vuelo.fechainicio}</td>
            <td class='centered'>${vuelo.fechafin}</td>
            <td class='centered'>${vuelo.companyia}</td>
            <td class='centered'>${vuelo.precio}</td>
            <td class='centered'>${vuelo.asientos}</td>
            </tr>`
        });
            document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
    }  
    if(origen=="" && destino=="" && fechainicio=="" && fechafin!=""){
        
        const response = await fetch("HTTP://localhost:8081/vuelos/fechafin?fechafin="+fechafin);
        const vuelos = await response.json();
        let tableBody=``;
        
        vuelos.forEach((vuelo, index) => {
            console.log(vuelo)     
            tableBody += `<tr>
            <td class='centered'>${vuelo.origen}</td>
            <td class='centered'>${vuelo.destino}</td>
            <td class='centered'>${vuelo.fechainicio}</td>
            <td class='centered'>${vuelo.fechafin}</td>
            <td class='centered'>${vuelo.companyia}</td>
            <td class='centered'>${vuelo.precio}</td>
            <td class='centered'>${vuelo.asientos}</td>
            </tr>`
        });
            document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
    }  
    
    
if(origen!="" && destino!="" && fechainicio=="" && fechafin==""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.origen==origen && vuelo.destino==destino) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen!="" && destino=="" && fechainicio!="" && fechafin==""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.origen==origen && vuelo.fechainicio==fechainicio) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen!="" && destino=="" && fechainicio=="" && fechafin!=""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.origen==origen && vuelo.fechafin==fechafin) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen!="" && destino=="" && fechainicio!="" && fechafin!=""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.origen==origen && vuelo.fechafin==fechafin && vuelo.fechainicio==fechainicio) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen=="" && destino=="" && fechainicio!="" && fechafin!=""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.fechafin==fechafin && vuelo.fechainicio==fechainicio) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen!="" && destino!="" && fechainicio!="" && fechafin==""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.origen==origen && vuelo.destino==destino  && vuelo.fechainicio==fechainicio) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen!="" && destino!="" && fechainicio=="" && fechafin!=""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.origen==origen && vuelo.destino==destino  && vuelo.fechafin==fechafin) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen=="" && destino!="" && fechainicio=="" && fechafin!=""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.destino==destino  && vuelo.fechafin==fechafin) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen=="" && destino!="" && fechainicio!="" && fechafin!=""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.destino==destino  && vuelo.fechafin==fechafin && vuelo.fechainicio==fechainicio) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
if(origen!="" && destino=="" && fechainicio=="" && fechafin==""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen?origen="+origen);
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)     
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}  
if(origen=="" && destino!="" && fechainicio=="" && fechafin==""){
    const response = await fetch("HTTP://localhost:8081/vuelos/destino?destino="+destino);
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)     
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}

if(origen!="" && destino!="" && fechainicio!="" && fechafin!=""){
    const response = await fetch("HTTP://localhost:8081/vuelos/origen");
    const vuelos = await response.json();
    let tableBody=``;
    
    vuelos.forEach((vuelo, index) => {
        console.log(vuelo)
        if(vuelo.origen==origen && vuelo.destino==destino && vuelo.fechainicio==fechainicio && vuelo.fechafin==fechafin) {    
        tableBody += `<tr>
        <td class='centered'>${vuelo.origen}</td>
        <td class='centered'>${vuelo.destino}</td>
        <td class='centered'>${vuelo.fechainicio}</td>
        <td class='centered'>${vuelo.fechafin}</td>
        <td class='centered'>${vuelo.companyia}</td>
        <td class='centered'>${vuelo.precio}</td>
        <td class='centered'>${vuelo.asientos}</td>
        </tr>`
        }
    });
        document.getElementById("tableBody_Vuelos").innerHTML = tableBody; 
}
};

function pedirVuelo(origen,destino,fechainicio,fechafin,companyia,precio,asientos){

    fetch ("HTTP://localhost:8081/vuelos/vuelosAdd" ,{
    method:"POST",
    mode:"cors",
    headers:{"Content-Type": "application/json" },
    body : JSON.stringify({origen:origen,destino:destino,fechainicio:fechainicio,fechafin:fechafin,companyia:companyia,precio:precio,asientos:asientos})
    })
    .then(response => response.json())
    .then(json => console.log(json))
    

};


const exampleModal = document.getElementById('exampleModal')
exampleModal.addEventListener('show.bs.modal', event => {
  // Button that triggered the modal
  const button = event.relatedTarget
  // Extract info from data-bs-* attributes
  const recipient = button.getAttribute('data-bs-whatever')
  // If necessary, you could initiate an AJAX request here
  // and then do the updating in a callback.
  //
  // Update the modal's content.
  const modalTitle = exampleModal.querySelector('.modal-title')
  const modalBodyInput = exampleModal.querySelector('.modal-body input')

  modalTitle.textContent = `New message to ${recipient}`
  modalBodyInput.value = recipient
})
const myModal = document.getElementById('myModal')
const myInput = document.getElementById('myInput')

myModal.addEventListener('shown.bs.modal', () => {
  myInput.focus()
});




